--
-- PostgreSQL database dump
--

\restrict d6OZtgPIZ9xkGCx2vvIoTfYJXYwUX0IEuTZdYb6k1I7Fidw5L8NfdkQ4YMlsmSw

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: referralstatus; Type: TYPE; Schema: public; Owner: user
--

CREATE TYPE public.referralstatus AS ENUM (
    'pending',
    'completed'
);


ALTER TYPE public.referralstatus OWNER TO "user";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_logs; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.admin_logs (
    id integer NOT NULL,
    admin_id bigint NOT NULL,
    action_type character varying(50) NOT NULL,
    user_id integer NOT NULL,
    old_value text,
    new_value text,
    reason text,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.admin_logs OWNER TO "user";

--
-- Name: admin_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.admin_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_logs_id_seq OWNER TO "user";

--
-- Name: admin_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.admin_logs_id_seq OWNED BY public.admin_logs.id;


--
-- Name: brands; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.brands (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    category_id integer NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.brands OWNER TO "user";

--
-- Name: brands_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.brands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.brands_id_seq OWNER TO "user";

--
-- Name: brands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.brands_id_seq OWNED BY public.brands.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    icon character varying(10) NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO "user";

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO "user";

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: models; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.models (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    brand_id integer NOT NULL,
    price_per_day integer NOT NULL,
    deposit integer,
    specs text,
    image_url character varying(500),
    review_url character varying(500),
    default_equipment text,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.models OWNER TO "user";

--
-- Name: models_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.models_id_seq OWNER TO "user";

--
-- Name: models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.models_id_seq OWNED BY public.models.id;


--
-- Name: password_reset_codes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.password_reset_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code character varying(10) NOT NULL,
    attempts integer DEFAULT 0,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.password_reset_codes OWNER TO "user";

--
-- Name: password_reset_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.password_reset_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_reset_codes_id_seq OWNER TO "user";

--
-- Name: password_reset_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.password_reset_codes_id_seq OWNED BY public.password_reset_codes.id;


--
-- Name: referral_codes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.referral_codes (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    owner_id integer NOT NULL,
    max_uses integer NOT NULL,
    used_count integer NOT NULL,
    expires_at timestamp without time zone,
    is_active boolean NOT NULL,
    is_permanent boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.referral_codes OWNER TO "user";

--
-- Name: referral_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.referral_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.referral_codes_id_seq OWNER TO "user";

--
-- Name: referral_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.referral_codes_id_seq OWNED BY public.referral_codes.id;


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.referrals (
    id integer NOT NULL,
    new_user_id integer NOT NULL,
    old_user_id integer NOT NULL,
    status public.referralstatus NOT NULL,
    registration_date timestamp without time zone NOT NULL,
    completion_date timestamp without time zone
);


ALTER TABLE public.referrals OWNER TO "user";

--
-- Name: referrals_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.referrals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.referrals_id_seq OWNER TO "user";

--
-- Name: referrals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.referrals_id_seq OWNED BY public.referrals.id;


--
-- Name: registration_requests; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.registration_requests (
    id integer NOT NULL,
    user_id integer,
    telegram_id bigint NOT NULL,
    full_name character varying(100),
    phone character varying(20),
    invited_by_id integer,
    instagram character varying(100),
    vkontakte character varying(100),
    status character varying(50) NOT NULL,
    risk_score integer NOT NULL,
    ip_address character varying(50),
    captcha_passed boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    reviewed_by integer,
    reviewed_at timestamp without time zone,
    review_comment text,
    instagram_status character varying(20)
);


ALTER TABLE public.registration_requests OWNER TO "user";

--
-- Name: registration_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.registration_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registration_requests_id_seq OWNER TO "user";

--
-- Name: registration_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.registration_requests_id_seq OWNED BY public.registration_requests.id;


--
-- Name: rentals; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.rentals (
    id integer NOT NULL,
    rental_number character varying(50) NOT NULL,
    user_id integer NOT NULL,
    model_id integer NOT NULL,
    price_per_day integer NOT NULL,
    total_price integer NOT NULL,
    deposit integer,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    status character varying(50) NOT NULL,
    notes text,
    created_by integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.rentals OWNER TO "user";

--
-- Name: rentals_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.rentals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rentals_id_seq OWNER TO "user";

--
-- Name: rentals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.rentals_id_seq OWNED BY public.rentals.id;


--
-- Name: security_settings; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.security_settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.security_settings OWNER TO "user";

--
-- Name: security_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.security_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.security_settings_id_seq OWNER TO "user";

--
-- Name: security_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.security_settings_id_seq OWNED BY public.security_settings.id;


--
-- Name: storm_logs; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.storm_logs (
    id integer NOT NULL,
    triggered_at timestamp without time zone NOT NULL,
    requests_count integer,
    ip_addresses text,
    action_taken character varying(100),
    resolved_at timestamp without time zone
);


ALTER TABLE public.storm_logs OWNER TO "user";

--
-- Name: storm_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.storm_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.storm_logs_id_seq OWNER TO "user";

--
-- Name: storm_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.storm_logs_id_seq OWNED BY public.storm_logs.id;


--
-- Name: telegram_auth_codes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.telegram_auth_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code character varying(10) NOT NULL,
    attempts integer DEFAULT 0,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.telegram_auth_codes OWNER TO "user";

--
-- Name: telegram_auth_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.telegram_auth_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.telegram_auth_codes_id_seq OWNER TO "user";

--
-- Name: telegram_auth_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.telegram_auth_codes_id_seq OWNED BY public.telegram_auth_codes.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount integer NOT NULL,
    reason character varying(200) NOT NULL,
    admin_id bigint,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.transactions OWNER TO "user";

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO "user";

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: user_logs; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action_type character varying(50) NOT NULL,
    action_details text,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.user_logs OWNER TO "user";

--
-- Name: user_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.user_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_logs_id_seq OWNER TO "user";

--
-- Name: user_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.user_logs_id_seq OWNED BY public.user_logs.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    user_agent text,
    ip_address character varying(50)
);


ALTER TABLE public.user_sessions OWNER TO "user";

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO "user";

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    telegram_id bigint NOT NULL,
    full_name character varying(100) NOT NULL,
    full_name_real character varying(100),
    phone character varying(20) NOT NULL,
    registration_date timestamp without time zone NOT NULL,
    balance integer NOT NULL,
    points_expiry_date timestamp without time zone,
    invited_by_id integer,
    is_admin boolean NOT NULL,
    blacklisted boolean NOT NULL,
    blacklist_reason character varying(200),
    blacklisted_at timestamp without time zone,
    verification_level character varying(20) NOT NULL,
    instagram character varying(100),
    vkontakte character varying(100),
    admin_notes text,
    verified_at timestamp without time zone,
    verified_by_id integer,
    badge character varying(10) NOT NULL,
    password_hash character varying(255),
    password_set_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO "user";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO "user";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: whitelist; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.whitelist (
    id integer NOT NULL,
    type character varying(50) NOT NULL,
    value character varying(255) NOT NULL,
    reason text,
    created_by integer,
    expires_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.whitelist OWNER TO "user";

--
-- Name: whitelist_id_seq; Type: SEQUENCE; Schema: public; Owner: user
--

CREATE SEQUENCE public.whitelist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.whitelist_id_seq OWNER TO "user";

--
-- Name: whitelist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: user
--

ALTER SEQUENCE public.whitelist_id_seq OWNED BY public.whitelist.id;


--
-- Name: admin_logs id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.admin_logs ALTER COLUMN id SET DEFAULT nextval('public.admin_logs_id_seq'::regclass);


--
-- Name: brands id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.brands ALTER COLUMN id SET DEFAULT nextval('public.brands_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: models id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.models ALTER COLUMN id SET DEFAULT nextval('public.models_id_seq'::regclass);


--
-- Name: password_reset_codes id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.password_reset_codes ALTER COLUMN id SET DEFAULT nextval('public.password_reset_codes_id_seq'::regclass);


--
-- Name: referral_codes id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referral_codes ALTER COLUMN id SET DEFAULT nextval('public.referral_codes_id_seq'::regclass);


--
-- Name: referrals id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referrals ALTER COLUMN id SET DEFAULT nextval('public.referrals_id_seq'::regclass);


--
-- Name: registration_requests id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.registration_requests ALTER COLUMN id SET DEFAULT nextval('public.registration_requests_id_seq'::regclass);


--
-- Name: rentals id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.rentals ALTER COLUMN id SET DEFAULT nextval('public.rentals_id_seq'::regclass);


--
-- Name: security_settings id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.security_settings ALTER COLUMN id SET DEFAULT nextval('public.security_settings_id_seq'::regclass);


--
-- Name: storm_logs id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.storm_logs ALTER COLUMN id SET DEFAULT nextval('public.storm_logs_id_seq'::regclass);


--
-- Name: telegram_auth_codes id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.telegram_auth_codes ALTER COLUMN id SET DEFAULT nextval('public.telegram_auth_codes_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: user_logs id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_logs ALTER COLUMN id SET DEFAULT nextval('public.user_logs_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: whitelist id; Type: DEFAULT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.whitelist ALTER COLUMN id SET DEFAULT nextval('public.whitelist_id_seq'::regclass);


--
-- Data for Name: admin_logs; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.admin_logs (id, admin_id, action_type, user_id, old_value, new_value, reason, created_at) FROM stdin;
1	0	update_real_name	1		Гулак Сергей	Обновление ФИО вручную	2026-03-24 05:52:35.426384
2	0	add_points	1	200	299	Тест	2026-03-24 08:27:58.111572
3	0	subtract_points	1	299	149	Аренда RF 24-70	2026-03-24 08:28:58.204259
5	0	add_points	4	200	300	Test	2026-04-02 15:29:21.171065
7	0	add_points	1	149	150	Тест	2026-04-06 15:17:15.405052
9	0	add_points	6	200	202	Тест	2026-04-09 06:41:05.282836
10	0	add_points	6	202	205	Тест	2026-04-09 06:41:32.878653
11	0	add_points	6	205	209	Тест	2026-04-09 06:50:48.678341
12	0	add_points	6	209	212	Тест	2026-04-09 06:51:40.150622
13	0	subtract_points	6	212	210	Тест	2026-04-09 06:52:12.143612
14	0	add_points	6	210	213	Тест	2026-04-09 06:53:27.914546
15	0	add_points	6	213	216	Тест	2026-04-09 06:57:49.44296
16	0	subtract_points	6	216	211	Тест	2026-04-09 06:58:07.41295
17	0	subtract_points	6	211	207	Тест	2026-04-09 08:29:43.131534
18	0	blacklist	6	False	True	Нарушение правил аренды	2026-04-09 08:45:00.089967
19	0	unblacklist	6	True	False	Снята блокировка: Нарушение правил аренды	2026-04-09 08:45:14.495278
20	0	blacklist	6	False	True	Нарушение правил аренды	2026-04-09 08:45:22.734093
21	0	unblacklist	6	True	False	Снята блокировка: Нарушение правил аренды	2026-04-09 09:02:48.272813
22	0	blacklist	6	False	True	Нарушение правил аренды	2026-04-09 09:02:54.25121
23	0	unblacklist	6	True	False	Снята блокировка: Нарушение правил аренды	2026-04-09 09:03:00.541129
24	0	blacklist	6	False	True	Нарушение правил аренды	2026-04-09 09:20:41.196785
25	0	unblacklist	6	True	False	Снята блокировка: Нарушение правил аренды	2026-04-09 09:21:09.399092
\.


--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.brands (id, name, category_id, sort_order, is_active, created_at) FROM stdin;
2	Canon	4	0	t	2026-04-09 07:51:38.490656
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.categories (id, name, icon, sort_order, is_active, created_at) FROM stdin;
4	Объективы	📦	0	t	2026-04-09 07:51:18.388414
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.models (id, name, brand_id, price_per_day, deposit, specs, image_url, review_url, default_equipment, is_active, created_at, updated_at) FROM stdin;
1	RF 24-70mm f/2.8	2	1900	\N					t	2026-04-09 07:52:18.21227	2026-04-09 07:54:37.553108
2	R	2	2000	\N					t	2026-04-09 12:05:08.995293	2026-04-09 12:05:08.995299
\.


--
-- Data for Name: password_reset_codes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.password_reset_codes (id, user_id, code, attempts, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: referral_codes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.referral_codes (id, code, owner_id, max_uses, used_count, expires_at, is_active, is_permanent, created_at) FROM stdin;
1	1_FBbmtgO0	1	0	0	\N	t	t	2026-03-24 10:02:19.283147
2	1_sgQ8dR1x	1	1	0	\N	f	f	2026-03-24 10:17:01.491344
3	1_YRE4rVUm	1	1	0	\N	f	f	2026-03-24 10:24:11.931637
4	1_YF0y4ELs	1	1	0	\N	f	f	2026-03-24 10:24:51.144598
5	1_NzqwbNd2	1	1	0	\N	f	f	2026-03-24 10:30:54.579675
6	1_DI7T7eRm	1	1	0	\N	t	f	2026-03-25 04:01:59.643564
7	1_wHQwCdWf	1	0	0	2026-04-01 04:12:02.048009	t	f	2026-03-25 04:12:02.050076
9	4_I6728W0Y	4	0	0	\N	t	t	2026-04-02 15:26:23.573247
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.referrals (id, new_user_id, old_user_id, status, registration_date, completion_date) FROM stdin;
2	5	4	pending	2026-04-02 15:27:34.591975	\N
3	6	1	pending	2026-04-06 15:50:00.123135	\N
\.


--
-- Data for Name: registration_requests; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.registration_requests (id, user_id, telegram_id, full_name, phone, invited_by_id, instagram, vkontakte, status, risk_score, ip_address, captcha_passed, created_at, reviewed_by, reviewed_at, review_comment, instagram_status) FROM stdin;
1	1	271186601	Серёга	+79876081798	\N	el_drinkins	el_drinkins	approved	0	271186601	f	2026-03-24 05:51:09.499706	\N	2026-03-24 05:52:16.059	\N	\N
8	4	149619664	Evgenij Chukavin	+79876016406	1	\N	\N	approved	0	149619664	f	2026-04-02 15:24:56.627461	1	2026-04-02 15:25:20.714181	\N	\N
9	5	6916406634	Evgenij	+79373604358	4	\N	\N	approved	0	6916406634	f	2026-04-02 15:27:12.667197	\N	2026-04-02 15:27:34.5922	\N	\N
10	6	6967224991	Сергей Take a Pic	+79870570807	1	\N	\N	approved	0	6967224991	f	2026-04-06 15:49:27.828472	1	2026-04-06 15:50:00.133481	\N	\N
\.


--
-- Data for Name: rentals; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.rentals (id, rental_number, user_id, model_id, price_per_day, total_price, deposit, start_date, end_date, status, notes, created_by, created_at, updated_at) FROM stdin;
1	R-202604-8170	6	1	1900	1900	\N	2026-04-10 00:00:00	2026-04-11 00:00:00	completed		1	2026-04-09 07:52:46.225922	2026-04-09 10:10:19.283637
2	R-202604-3085	1	1	1900	1900	\N	2026-04-17 00:00:00	2026-04-18 00:00:00	completed		1	2026-04-09 11:02:36.625796	2026-04-09 11:03:21.6318
3	R-202604-3268	6	1	1900	5700	\N	2025-11-05 00:00:00	2025-11-08 00:00:00	completed		1	2026-04-09 11:17:04.421568	2026-04-09 11:17:04.421574
4	R-202604-1320	6	1	1900	1900	\N	2026-04-01 00:00:00	2026-04-02 00:00:00	completed		1	2026-04-09 11:17:52.041798	2026-04-09 11:17:52.041804
5	R-202604-4807	6	1	1900	10900	\N	2025-10-16 00:00:00	2025-11-16 00:00:00	completed		1	2026-04-09 12:14:47.447304	2026-04-09 12:14:47.44731
6	R-202604-2283	6	2	2000	10900	\N	2025-07-09 00:00:00	2025-08-09 00:00:00	completed		1	2026-04-09 12:16:16.985156	2026-04-09 12:16:16.985161
7	R-202604-6427	6	2	2000	15000	\N	2024-12-01 00:00:00	2024-12-12 00:00:00	completed		1	2026-04-09 12:20:14.904411	2026-04-09 12:20:21.638563
\.


--
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.security_settings (id, key, value, updated_at) FROM stdin;
2	storm_threshold	100	2026-03-23 08:57:57.480004
3	storm_cooldown	60	2026-03-23 08:57:57.48194
4	ip_limit	50	2026-03-23 08:57:57.483541
5	captcha_enabled	false	2026-03-23 08:57:57.484891
6	manual_review_enabled	false	2026-03-23 08:57:57.486224
7	whitelist_enabled	false	2026-03-23 08:57:57.487527
\.


--
-- Data for Name: storm_logs; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.storm_logs (id, triggered_at, requests_count, ip_addresses, action_taken, resolved_at) FROM stdin;
\.


--
-- Data for Name: telegram_auth_codes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.telegram_auth_codes (id, user_id, code, attempts, expires_at, created_at) FROM stdin;
1	1	549255	0	2026-04-10 04:40:59.046319	2026-04-10 04:30:59.0482
2	1	879710	0	2026-04-10 05:42:36.259901	2026-04-10 05:32:36.261484
3	1	435556	0	2026-04-10 05:53:25.191558	2026-04-10 05:43:25.192312
4	1	260793	0	2026-04-10 05:55:15.704603	2026-04-10 05:45:15.705207
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.transactions (id, user_id, amount, reason, admin_id, "timestamp") FROM stdin;
1	1	200	Бонус за регистрацию	\N	2026-03-24 05:52:16.066258
2	1	99	Тест	0	2026-03-24 08:27:58.119425
3	1	-150	Аренда RF 24-70	0	2026-03-24 08:28:58.209344
5	5	200	Бонус за регистрацию	\N	2026-04-02 15:27:34.600148
6	4	100	Test	0	2026-04-02 15:29:21.181491
8	1	1	Тест	0	2026-04-06 15:17:15.407898
9	6	2	Тест	0	2026-04-09 06:41:05.291269
10	6	3	Тест	0	2026-04-09 06:41:32.88084
11	6	4	Тест	0	2026-04-09 06:50:48.682558
12	6	3	Тест	0	2026-04-09 06:51:40.152886
13	6	-2	Тест	0	2026-04-09 06:52:12.152608
14	6	3	Тест	0	2026-04-09 06:53:27.922603
15	6	3	Тест	0	2026-04-09 06:57:49.449744
16	6	-5	Тест	0	2026-04-09 06:58:07.416
17	6	-4	Тест	0	2026-04-09 08:29:43.138808
18	6	0	⛔ Блокировка: Нарушение правил аренды	0	2026-04-09 08:45:00.085969
19	6	0	✅ Разблокировка аккаунта	0	2026-04-09 08:45:14.494233
20	6	0	⛔ Блокировка: Нарушение правил аренды	0	2026-04-09 08:45:22.733177
21	6	0	✅ Разблокировка аккаунта	0	2026-04-09 09:02:48.269588
22	6	0	⛔ Блокировка: Нарушение правил аренды	0	2026-04-09 09:02:54.250106
23	6	0	✅ Разблокировка аккаунта	0	2026-04-09 09:03:00.540147
24	6	0	⛔ Блокировка: Нарушение правил аренды	0	2026-04-09 09:20:41.193034
25	6	0	✅ Разблокировка аккаунта	0	2026-04-09 09:21:09.397832
\.


--
-- Data for Name: user_logs; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_logs (id, user_id, action_type, action_details, created_at) FROM stdin;
1	1	command	/start	2026-03-24 06:01:45.253251
2	1	command	/start	2026-03-24 06:01:48.860751
3	1	command	/start	2026-03-24 06:07:29.788152
4	1	command	/start	2026-03-24 06:14:39.121272
5	1	command	/admin	2026-03-24 06:52:25.629983
6	1	command	/users	2026-03-24 06:52:40.06691
7	1	command	/stats	2026-03-24 06:52:44.98907
8	1	command	/review	2026-03-24 06:52:53.169588
9	1	command	/start	2026-03-24 06:53:04.210035
10	1	view_balance	Баланс: 299	2026-03-24 08:28:07.421687
11	1	view_history	Просмотр истории (всего операций: 2)	2026-03-24 08:28:15.243791
12	1	view_balance	Баланс: 149	2026-03-24 08:29:14.607934
13	1	view_history	Просмотр истории (всего операций: 3)	2026-03-24 08:29:20.841895
16	1	invite_friend	Открыл страницу приглашения	2026-03-24 10:02:19.291553
17	1	invite_friend	Открыл страницу приглашения	2026-03-24 10:15:48.238538
18	1	callback	admin_create_link	2026-03-24 10:16:55.555951
19	1	callback	admin_create_single	2026-03-24 10:17:01.483676
20	1	callback	code_stats_2	2026-03-24 10:17:21.974584
21	1	callback	admin_back_to_links	2026-03-24 10:17:24.088634
22	1	callback	admin_back_to_links	2026-03-24 10:17:27.212141
23	1	callback	delete_code_2	2026-03-24 10:17:46.027501
24	1	callback	delete_code_2	2026-03-24 10:22:14.075227
25	1	callback	delete_code_2	2026-03-24 10:22:35.127612
26	1	callback	delete_code_2	2026-03-24 10:22:52.70781
27	1	callback	admin_create_link	2026-03-24 10:24:10.619401
28	1	callback	admin_create_single	2026-03-24 10:24:11.92399
29	1	callback	delete_code_3	2026-03-24 10:24:21.332321
30	1	callback	admin_create_link	2026-03-24 10:24:50.075632
31	1	callback	admin_create_single	2026-03-24 10:24:51.138849
32	1	callback	delete_code_4	2026-03-24 10:25:27.557449
33	1	callback	admin_create_link	2026-03-24 10:30:51.868494
34	1	callback	admin_create_single	2026-03-24 10:30:54.572376
35	1	callback	delete_code_5	2026-03-24 10:31:00.936237
36	1	callback	back_to_invite	2026-03-24 11:33:24.697914
37	1	help	Просмотр справки	2026-03-24 11:33:35.045223
38	1	command	/admin	2026-03-24 11:33:45.96263
39	1	command	/review	2026-03-24 11:33:53.101167
40	1	command	/stats	2026-03-24 11:33:56.989952
41	1	command	/users	2026-03-24 11:34:11.48652
42	1	command	/review	2026-03-24 11:49:02.796091
43	1	callback	approve_7	2026-03-24 11:50:25.671518
45	1	command	/users	2026-03-24 11:58:16.224258
47	1	callback	admin_create_link	2026-03-25 04:01:57.426829
48	1	callback	admin_create_single	2026-03-25 04:01:59.63647
49	1	callback	admin_create_link	2026-03-25 04:11:58.626145
50	1	callback	admin_create_temp_7	2026-03-25 04:12:02.04161
53	1	view_balance	Баланс: 149	2026-03-26 10:23:06.391806
54	1	help	Просмотр справки	2026-03-26 10:23:09.245564
55	1	help	Просмотр справки	2026-03-26 10:37:38.903656
56	1	view_balance	Баланс: 149	2026-03-26 10:37:55.341093
57	1	view_history	Просмотр истории (всего операций: 3)	2026-03-26 10:37:57.154784
58	1	help	Просмотр справки	2026-03-26 10:38:02.787357
59	1	help	Просмотр справки	2026-03-26 10:38:55.872008
60	1	help	Просмотр справки	2026-03-26 10:42:35.293452
61	1	command	/regulations	2026-03-26 10:43:30.147829
62	1	view_history	Просмотр истории (всего операций: 3)	2026-03-26 15:19:52.365468
63	1	view_balance	Баланс: 149	2026-03-26 15:19:57.78767
64	1	view_balance	Баланс: 149	2026-03-27 06:34:17.082069
65	1	view_history	Просмотр истории (всего операций: 3)	2026-03-27 06:57:53.587247
66	1	help	Просмотр справки	2026-03-27 07:00:27.113608
67	1	invite_friend	Открыл страницу приглашения	2026-03-27 07:00:36.172299
68	1	command	/regulations	2026-03-27 07:01:50.355521
69	1	help	Просмотр справки	2026-03-27 08:47:33.223209
70	1	help	Просмотр справки	2026-03-27 08:55:46.75904
71	1	view_balance	Баланс: 149	2026-03-27 08:55:53.169854
72	1	help	Просмотр справки	2026-03-27 08:55:54.626482
73	1	view_balance	Баланс: 149	2026-03-27 08:56:36.6944
74	1	help	Просмотр справки	2026-03-27 08:56:41.285046
75	1	command	/start	2026-03-27 08:59:14.855044
76	1	view_friends	Просмотр списка друзей	2026-03-27 09:00:46.746319
77	1	help	Просмотр справки	2026-03-27 09:00:50.531307
78	1	command	/regulations	2026-03-27 09:01:47.220893
79	1	view_history	Просмотр истории (всего операций: 3)	2026-03-27 09:14:47.759156
80	1	view_balance	Баланс: 149	2026-03-27 09:15:01.19666
81	1	view_balance	Баланс: 149	2026-03-27 09:21:59.603931
82	1	view_balance	Баланс: 149	2026-03-27 09:21:59.70263
83	1	help	Просмотр справки	2026-03-27 09:22:02.498644
84	1	help	Просмотр справки	2026-03-27 09:22:04.701569
85	1	command	/regulations	2026-03-27 09:22:41.678435
86	1	view_friends	Просмотр списка друзей	2026-03-27 09:26:25.733797
87	1	invite_friend	Открыл страницу приглашения	2026-03-27 09:27:41.970676
88	1	callback	back_to_main	2026-03-27 09:28:33.55737
89	1	invite_friend	Открыл страницу приглашения	2026-03-27 09:28:52.54652
90	1	callback	admin_create_link	2026-03-27 09:28:59.167914
91	1	view_balance	Баланс: 149	2026-03-27 17:34:41.167069
92	1	invite_friend	Открыл страницу приглашения	2026-03-27 17:35:11.857734
93	1	view_history	Просмотр истории (всего операций: 3)	2026-03-27 17:35:45.004018
94	1	command	/admin	2026-03-27 17:36:15.49621
95	1	command	/review	2026-03-27 17:36:29.659617
96	1	command	/blacklist	2026-03-27 17:37:49.495789
97	1	command	/users	2026-03-27 17:38:10.911071
98	1	view_friends	Просмотр списка друзей	2026-03-27 17:38:43.948764
99	1	view_balance	Баланс: 149	2026-04-01 16:33:49.347565
100	1	view_balance	Баланс: 149	2026-04-02 09:10:35.450716
101	1	view_friends	Просмотр списка друзей	2026-04-02 09:10:41.773279
102	1	view_history	Просмотр истории (всего операций: 3)	2026-04-02 09:10:45.699335
103	1	view_balance	Баланс: 149	2026-04-02 12:51:22.371346
104	1	view_history	Просмотр истории (всего операций: 3)	2026-04-02 12:51:33.648654
105	1	view_friends	Просмотр списка друзей	2026-04-02 12:51:37.821772
106	1	invite_friend	Открыл страницу приглашения	2026-04-02 12:51:45.264187
107	1	help	Просмотр справки	2026-04-02 12:53:49.860908
108	1	command	/regulations	2026-04-02 13:20:36.022262
109	1	command	/admin	2026-04-02 13:40:02.709159
110	1	command	/stats	2026-04-02 13:40:08.685417
111	1	command	/admin	2026-04-02 15:25:12.112629
112	1	command	/review	2026-04-02 15:25:14.476146
113	1	callback	approve_8	2026-04-02 15:25:20.692701
114	4	registration_approved	Одобрено администратором 271186601	2026-04-02 15:25:20.717259
115	4	command	/start	2026-04-02 15:25:25.893333
116	4	view_balance	Баланс: 200	2026-04-02 15:25:30.372264
117	4	view_history	Просмотр истории (всего операций: 0)	2026-04-02 15:25:32.468393
118	4	view_friends	Просмотр списка друзей	2026-04-02 15:25:34.323442
119	4	help	Просмотр справки	2026-04-02 15:25:42.164857
120	4	view_history	Просмотр истории (всего операций: 0)	2026-04-02 15:26:09.978312
121	4	view_friends	Просмотр списка друзей	2026-04-02 15:26:20.004263
122	4	callback	back_to_invite	2026-04-02 15:26:23.515813
123	4	view_balance	Баланс: 300	2026-04-02 15:29:36.632546
124	1	command	/start	2026-04-03 08:23:11.663925
125	1	view_balance	Баланс: 149	2026-04-03 08:23:13.050779
126	1	view_history	Просмотр истории (всего операций: 3)	2026-04-03 08:25:47.083935
130	1	view_balance	Баланс: 149	2026-04-06 14:15:04.659095
131	1	view_balance	Баланс: 149	2026-04-06 15:16:11.577659
132	1	view_balance	Баланс: 150	2026-04-06 15:17:18.80244
133	1	view_friends	Просмотр списка друзей	2026-04-06 15:30:07.422103
134	1	command	/admin	2026-04-06 15:49:53.435578
135	1	command	/review	2026-04-06 15:49:56.138058
136	1	callback	approve_10	2026-04-06 15:50:00.105183
137	6	registration_approved	Одобрено администратором 271186601	2026-04-06 15:50:00.139539
138	6	view_balance	Баланс: 200	2026-04-06 15:50:35.721873
139	1	view_balance	Баланс: 150	2026-04-07 17:13:26.385212
140	6	view_balance	Баланс: 200	2026-04-07 17:14:04.623457
141	6	view_balance	Баланс: 200	2026-04-07 17:14:04.666637
142	1	view_balance	Баланс: 150	2026-04-08 06:17:41.36486
143	1	view_balance	Баланс: 150	2026-04-08 07:12:59.701731
144	1	view_balance	Баланс: 150	2026-04-08 07:52:08.919201
145	1	view_balance	Баланс: 150	2026-04-08 07:52:11.954404
146	1	view_balance	Баланс: 150	2026-04-08 08:58:06.011946
147	1	view_balance	Баланс: 150	2026-04-08 10:44:34.293691
148	1	view_balance	Баланс: 150	2026-04-08 10:57:40.877496
149	1	view_balance	Баланс: 150	2026-04-08 14:26:28.921696
150	1	view_friends	Просмотр списка друзей	2026-04-08 14:33:25.416347
151	1	view_balance	Баланс: 150	2026-04-08 14:52:59.567553
152	1	view_friends	Просмотр списка друзей	2026-04-08 14:53:01.340663
153	1	view_history	Просмотр истории (всего операций: 4)	2026-04-08 14:53:02.931403
154	1	invite_friend	Открыл страницу приглашения	2026-04-08 14:53:26.028593
155	6	view_balance	Баланс: 207	2026-04-09 09:03:30.548782
156	1	view_friends	Просмотр списка друзей	2026-04-09 10:02:42.903194
157	1	view_balance	Баланс: 150	2026-04-10 05:32:46.713419
158	6	view_balance	Баланс: 207	2026-04-10 05:33:19.380093
159	1	view_history	Просмотр истории (всего операций: 4)	2026-04-10 05:34:04.506755
160	1	command	/start	2026-04-10 05:43:02.967766
161	1	view_balance	Баланс: 150	2026-04-10 05:43:05.555376
162	1	view_history	Просмотр истории (всего операций: 4)	2026-04-10 05:43:12.706388
163	1	command	/start	2026-04-10 06:28:42.751567
164	1	command	/start	2026-04-10 06:28:43.25192
165	1	command	/start	2026-04-10 06:28:43.266625
166	1	command	/start	2026-04-10 06:28:43.276882
167	1	view_balance	Баланс: 150	2026-04-10 06:28:43.274821
168	1	command	/start	2026-04-10 06:28:43.283257
169	1	view_balance	Баланс: 150	2026-04-10 06:28:43.294468
170	1	command	/start	2026-04-10 08:18:22.900533
171	1	command	/start	2026-04-10 08:18:22.909042
172	1	command	/start	2026-04-10 08:18:22.913641
173	1	view_balance	Баланс: 150	2026-04-10 08:18:22.922703
174	1	view_balance	Баланс: 150	2026-04-10 08:18:22.940613
175	1	view_balance	Баланс: 150	2026-04-10 08:18:23.047791
176	1	command	/start	2026-04-10 10:18:12.098526
177	6	command	/start	2026-04-10 10:18:12.097482
178	1	command	/start	2026-04-10 10:18:12.099803
179	1	command	/start	2026-04-10 10:18:12.109887
180	1	view_balance	Баланс: 150	2026-04-10 10:18:12.118128
181	6	view_balance	Баланс: 207	2026-04-10 10:18:33.064743
182	1	view_history	Просмотр истории (всего операций: 4)	2026-04-10 10:18:48.744575
183	1	command	/start	2026-04-10 11:58:32.236102
184	1	command	/start	2026-04-10 11:58:32.25445
185	1	command	/start	2026-04-10 11:58:32.266202
186	1	view_friends	Просмотр списка друзей	2026-04-10 12:09:36.590463
187	1	command	/start	2026-04-10 12:10:07.314249
188	6	command	/start	2026-04-10 12:48:27.91219
189	1	command	/start	2026-04-10 12:49:04.277182
190	6	command	/start	2026-04-10 12:49:11.982555
191	1	view_balance	Баланс: 150	2026-04-10 12:49:49.246877
192	1	view_balance	Баланс: 150	2026-04-10 13:37:57.240264
193	1	command	/start	2026-04-10 13:38:00.838237
194	1	command	/start	2026-04-10 17:27:34.239757
195	1	command	/start	2026-04-10 17:27:34.243923
196	1	command	/start	2026-04-10 20:11:57.847502
197	1	view_friends	Просмотр списка друзей	2026-04-10 20:11:57.852595
198	1	command	/start	2026-04-11 04:08:18.410715
199	1	command	/start	2026-04-11 15:44:15.593253
200	1	command	/start	2026-04-11 15:48:28.099812
201	1	view_balance	Баланс: 150	2026-04-11 15:48:32.411344
202	1	command	/start	2026-04-12 07:44:00.079285
203	1	command	/start	2026-04-12 07:53:47.733352
204	1	view_history	Просмотр истории (всего операций: 4)	2026-04-12 07:53:47.752062
205	1	command	/start	2026-04-12 18:05:08.865007
206	1	command	/start	2026-04-13 06:17:27.78482
207	1	view_balance	Баланс: 150	2026-04-13 13:49:01.109796
208	1	view_friends	Просмотр списка друзей	2026-04-13 18:53:04.852856
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_sessions (id, user_id, session_token, expires_at, created_at, user_agent, ip_address) FROM stdin;
1	1	r8FFY2-l12XO0Fbh7v06IByWBf6Vw4etVp-hSIBAXH8	2026-04-10 04:29:31.249713	2026-04-09 04:29:31.251323	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	94.41.209.254
2	1	vjtcNXRCFWOTju0dGlODC8IaorgJMmOU5rMxNqMhsxc	2026-04-10 04:35:15.737504	2026-04-09 04:35:15.740483	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	94.41.209.254
4	1	zlcuYDHpepWr2ReuDZuCGNoKnVxVt64g5Wzeh59uCgw	2026-04-10 09:26:24.329207	2026-04-09 09:26:24.331686	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	94.41.209.254
5	1	ku33ra-XrO6drfKIcclo-4TKQAVFWAdRzzoHMCS5D0s	2026-04-10 09:28:04.970395	2026-04-09 09:28:04.971782	Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1	94.41.209.254
6	1	rMpdxvCyB2rBQNmgEjG_VG9EaMhm44MCYDSDX6DJuIg	2026-04-10 09:45:55.813197	2026-04-09 09:45:55.816967	Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1	94.41.209.254
7	1	6TLZwPXjGRbJAefUF0AxFrrx8brAYfKpjTOa1ht6yg8	2026-04-10 11:40:36.066116	2026-04-09 11:40:36.069214	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	94.41.209.254
8	1	rQicGUz4BRnMVO6OQdo_aomZNhcF0lKwKRUZTQUU21k	2026-04-11 07:08:37.127145	2026-04-10 07:08:37.129764	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	159.100.20.37
9	1	C6mCV3Ni0LuapiEegjE7Ki1BCDthm6EINgHZO11O1N0	2026-04-12 18:12:57.638502	2026-04-11 18:12:57.641116	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	94.41.209.254
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.users (id, telegram_id, full_name, full_name_real, phone, registration_date, balance, points_expiry_date, invited_by_id, is_admin, blacklisted, blacklist_reason, blacklisted_at, verification_level, instagram, vkontakte, admin_notes, verified_at, verified_by_id, badge, password_hash, password_set_at) FROM stdin;
5	6916406634	Evgenij	\N	+79373604358	2026-04-02 15:27:34.588846	200	\N	4	f	f	\N	\N	basic	\N	\N	\N	2026-04-02 15:27:34.585286	\N	🟢	\N	\N
4	149619664	Evgenij Chukavin	\N	+79876016406	2026-04-02 15:25:20.705553	300	2027-04-02 15:29:21.167024	1	f	f	\N	\N	basic	\N	\N	\N	2026-04-02 15:25:20.701236	1	🟢	\N	\N
1	271186601	Серёга	Гулак Сергей	+79876081798	2026-03-24 05:52:16.054499	150	2027-04-06 15:17:15.403576	\N	f	f	\N	\N	basic	el_drinkins	el_drinkins	Это мой аккаунт админа	2026-03-24 05:52:16.050487	\N	🟢	e0a0feba7c8de43cd9412d3e56a09dd9a72652e8142eb6e87cc089cc6c1fc607	2026-04-09 04:29:20.485644
6	6967224991	Сергей Take a Pic	\N	+79870570807	2026-04-06 15:50:00.119557	207	2026-07-08 12:20:14.907922	1	f	f	\N	\N	basic	\N	\N	\N	2026-04-06 15:50:00.11669	\N	🟢	\N	\N
\.


--
-- Data for Name: whitelist; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.whitelist (id, type, value, reason, created_by, expires_at, created_at) FROM stdin;
\.


--
-- Name: admin_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.admin_logs_id_seq', 25, true);


--
-- Name: brands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.brands_id_seq', 2, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.categories_id_seq', 4, true);


--
-- Name: models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.models_id_seq', 2, true);


--
-- Name: password_reset_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.password_reset_codes_id_seq', 2, true);


--
-- Name: referral_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.referral_codes_id_seq', 9, true);


--
-- Name: referrals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.referrals_id_seq', 3, true);


--
-- Name: registration_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.registration_requests_id_seq', 10, true);


--
-- Name: rentals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.rentals_id_seq', 7, true);


--
-- Name: security_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.security_settings_id_seq', 7, true);


--
-- Name: storm_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.storm_logs_id_seq', 1, false);


--
-- Name: telegram_auth_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.telegram_auth_codes_id_seq', 4, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.transactions_id_seq', 25, true);


--
-- Name: user_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.user_logs_id_seq', 208, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 9, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: whitelist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: user
--

SELECT pg_catalog.setval('public.whitelist_id_seq', 1, false);


--
-- Name: admin_logs admin_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.admin_logs
    ADD CONSTRAINT admin_logs_pkey PRIMARY KEY (id);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: password_reset_codes password_reset_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.password_reset_codes
    ADD CONSTRAINT password_reset_codes_pkey PRIMARY KEY (id);


--
-- Name: referral_codes referral_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referral_codes
    ADD CONSTRAINT referral_codes_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_new_user_id_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_new_user_id_key UNIQUE (new_user_id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: registration_requests registration_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_pkey PRIMARY KEY (id);


--
-- Name: rentals rentals_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_pkey PRIMARY KEY (id);


--
-- Name: rentals rentals_rental_number_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_rental_number_key UNIQUE (rental_number);


--
-- Name: security_settings security_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_key_key UNIQUE (key);


--
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- Name: storm_logs storm_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.storm_logs
    ADD CONSTRAINT storm_logs_pkey PRIMARY KEY (id);


--
-- Name: telegram_auth_codes telegram_auth_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.telegram_auth_codes
    ADD CONSTRAINT telegram_auth_codes_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_logs user_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_logs
    ADD CONSTRAINT user_logs_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_key UNIQUE (session_token);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: whitelist whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.whitelist
    ADD CONSTRAINT whitelist_pkey PRIMARY KEY (id);


--
-- Name: idx_auth_codes_user; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_auth_codes_user ON public.telegram_auth_codes USING btree (user_id);


--
-- Name: idx_reset_codes_user; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_reset_codes_user ON public.password_reset_codes USING btree (user_id);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_sessions_token ON public.user_sessions USING btree (session_token);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_sessions_user ON public.user_sessions USING btree (user_id);


--
-- Name: ix_referral_codes_code; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_referral_codes_code ON public.referral_codes USING btree (code);


--
-- Name: ix_referral_codes_owner_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_referral_codes_owner_id ON public.referral_codes USING btree (owner_id);


--
-- Name: ix_transactions_user_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_transactions_user_id ON public.transactions USING btree (user_id);


--
-- Name: ix_user_logs_action_type; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_user_logs_action_type ON public.user_logs USING btree (action_type);


--
-- Name: ix_user_logs_created_at; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_user_logs_created_at ON public.user_logs USING btree (created_at);


--
-- Name: ix_user_logs_user_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX ix_user_logs_user_id ON public.user_logs USING btree (user_id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: user
--

CREATE UNIQUE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: brands brands_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: models models_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brands(id) ON DELETE CASCADE;


--
-- Name: password_reset_codes password_reset_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.password_reset_codes
    ADD CONSTRAINT password_reset_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referral_codes referral_codes_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referral_codes
    ADD CONSTRAINT referral_codes_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_new_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_new_user_id_fkey FOREIGN KEY (new_user_id) REFERENCES public.users(id);


--
-- Name: referrals referrals_old_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_old_user_id_fkey FOREIGN KEY (old_user_id) REFERENCES public.users(id);


--
-- Name: registration_requests registration_requests_invited_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_invited_by_id_fkey FOREIGN KEY (invited_by_id) REFERENCES public.users(id);


--
-- Name: registration_requests registration_requests_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: registration_requests registration_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.registration_requests
    ADD CONSTRAINT registration_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rentals rentals_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rentals rentals_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE CASCADE;


--
-- Name: rentals rentals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: telegram_auth_codes telegram_auth_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.telegram_auth_codes
    ADD CONSTRAINT telegram_auth_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_logs user_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_logs
    ADD CONSTRAINT user_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_invited_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_invited_by_id_fkey FOREIGN KEY (invited_by_id) REFERENCES public.users(id);


--
-- Name: users users_verified_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_verified_by_id_fkey FOREIGN KEY (verified_by_id) REFERENCES public.users(id);


--
-- Name: whitelist whitelist_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.whitelist
    ADD CONSTRAINT whitelist_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict d6OZtgPIZ9xkGCx2vvIoTfYJXYwUX0IEuTZdYb6k1I7Fidw5L8NfdkQ4YMlsmSw

